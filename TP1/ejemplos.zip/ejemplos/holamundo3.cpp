#include<pthread.h>
#include<stdio.h>

#define  CANT_THREADS  8

void *aloha_honua(void *p_minumero)
{
    int minumero = *((int *) p_minumero);
    printf("Aloha honua! Soy el thread nro. %d.\n", minumero);
    return NULL;
}

int main(int argc, char **argv) 
{
    pthread_t thread[CANT_THREADS];
    int tids[CANT_THREADS], tid;

    for (tid = 0; tid < CANT_THREADS; ++tid) {
         tids[tid] = tid;
         pthread_create(&thread[tid], NULL, aloha_honua, &tids[tid]);
    }

    for (tid = 0; tid < CANT_THREADS; ++tid)
         pthread_join(thread[tid], NULL);

    return 0;
}
