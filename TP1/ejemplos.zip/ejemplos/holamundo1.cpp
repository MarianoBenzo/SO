#include <pthread.h>
#include <iostream>
using namespace std;

void *hola_mundo(void *vargp)
{
	cout<<"Hola Mundo"<<endl;
	return NULL;
}

int main() {
	pthread_t tid;
	
	pthread_create(&tid, NULL, hola_mundo, NULL);
	pthread_join(tid, NULL);
	
	return 0;
}
