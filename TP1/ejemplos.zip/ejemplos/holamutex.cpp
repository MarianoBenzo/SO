#include <pthread.h>
#include <stdio.h>

#define  CANT_THREADS  8
//declaro el struct a utilizar
struct mutint{
    pthread_mutex_t *mutex;
    int number;
};

void *hola_mundo(void *p_struct)
{
    struct mutint* mistruct= (struct mutint *)p_struct;
    pthread_mutex_t *mutex = mistruct->mutex;

    pthread_mutex_lock(mutex);
    //notar que a pesar de ejecutar cada uno con su número,
    // el orden puede no respetarse en la salida
    mistruct->number++;
    printf("Hola mundo! Soy el thread que ejecuto %d° la sección crítica.\n",mistruct->number);
    pthread_mutex_unlock(mutex);
    return NULL;
}

int main(int argc, char **argv)
{
    struct mutint mistruct;
    pthread_t thread[CANT_THREADS]; int tid;

    //creacion de mutex sin atributos
    pthread_mutex_t mutex;
    pthread_mutex_init(&mutex,NULL);

    int pos = 0;

    //inicializo struct a pasar
    mistruct.mutex=&mutex;
    mistruct.number=pos;

    //creo las threads
    for (tid = 0; tid < CANT_THREADS; ++tid)
        pthread_create(&thread[tid], NULL, hola_mundo, &mistruct);

    //espero que cada thread termine
    for (tid = 0; tid < CANT_THREADS; ++tid)
        pthread_join(thread[tid], NULL);

    //destruyo el mutex
    pthread_mutex_destroy(&mutex);

    return 0;
}

